Jesus Magana
jmagana7
pa1

README			This file
List.c			Where the functions are defined
List.h			Where the functions are called for the first time in the ADT
ListTest.c 		The file that tests the list adt
MAKEFILE		The makefile that compiles the store.c and the ListTest.c
store.c         The file that is actually used to print out the list of books everyone bought

This program takes in a text file and reads in the first line to make an array that is of that size. Then it will read in how many purchases will be made and use that as the upper bound for a for loop. Then it will read in the first integer and use that to see what customer bought what item and it will sort the items as it reads them in.